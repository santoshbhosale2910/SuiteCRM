<?php
// created: 2018-07-11 20:57:32
$dictionary["AOS_Products"]["fields"]["sb_pricebook_aos_products"] = array (
  'name' => 'sb_pricebook_aos_products',
  'type' => 'link',
  'relationship' => 'sb_pricebook_aos_products',
  'source' => 'non-db',
  'module' => 'sb_pricebook',
  'bean_name' => 'sb_pricebook',
  'side' => 'right',
  'vname' => 'LBL_SB_PRICEBOOK_AOS_PRODUCTS_FROM_SB_PRICEBOOK_TITLE',
);
