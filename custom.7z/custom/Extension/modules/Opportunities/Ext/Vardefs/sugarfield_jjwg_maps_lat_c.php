<?php
 // created: 2018-06-05 21:18:12
$dictionary['Opportunity']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 ?>