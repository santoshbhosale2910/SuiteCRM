<?php
 // created: 2018-06-05 21:18:03
$dictionary['Contact']['fields']['jjwg_maps_address_c']['inline_edit']=1;

 ?>