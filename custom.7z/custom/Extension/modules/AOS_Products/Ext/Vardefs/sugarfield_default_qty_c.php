<?php
 // created: 2018-07-11 19:14:47
$dictionary['AOS_Products']['fields']['default_qty_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['default_qty_c']['labelValue']='Default Qty';

 ?>