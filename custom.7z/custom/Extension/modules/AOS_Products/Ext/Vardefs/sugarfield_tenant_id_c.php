<?php
 // created: 2018-07-11 19:16:15
$dictionary['AOS_Products']['fields']['tenant_id_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['tenant_id_c']['labelValue']='Tenant Id';

 ?>