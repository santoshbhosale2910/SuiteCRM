<?php
 // created: 2018-07-11 19:22:38
$dictionary['AOS_Products']['fields']['charge_type_id_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['charge_type_id_c']['labelValue']='Charge Type Id';

 ?>