<?php
 // created: 2018-07-11 19:26:03
$dictionary['AOS_Products']['fields']['uom_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['uom_c']['labelValue']='UOM';

 ?>