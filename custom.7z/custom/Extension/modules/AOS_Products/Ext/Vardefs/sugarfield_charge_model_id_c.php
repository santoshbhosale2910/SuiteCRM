<?php
 // created: 2018-07-11 19:19:24
$dictionary['AOS_Products']['fields']['charge_model_id_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['charge_model_id_c']['labelValue']='Charge Model Id';

 ?>