<?php
 // created: 2018-07-11 19:23:28
$dictionary['AOS_Products']['fields']['event_id_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['event_id_c']['labelValue']='Event Id';

 ?>