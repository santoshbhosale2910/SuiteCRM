<?php
 // created: 2018-07-11 19:13:29
$dictionary['AOS_Products']['fields']['version_optimized_lock_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['version_optimized_lock_c']['labelValue']='Version Optimized Lock';

 ?>