<?php
 // created: 2018-06-05 21:18:00
$dictionary['Case']['fields']['jjwg_maps_geocode_status_c']['inline_edit']=1;

 ?>