<?php
 // created: 2018-06-05 21:17:56
$dictionary['Account']['fields']['jjwg_maps_address_c']['inline_edit']=1;

 ?>