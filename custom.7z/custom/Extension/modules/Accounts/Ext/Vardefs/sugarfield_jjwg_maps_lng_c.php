<?php
 // created: 2018-06-05 21:17:54
$dictionary['Account']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 ?>