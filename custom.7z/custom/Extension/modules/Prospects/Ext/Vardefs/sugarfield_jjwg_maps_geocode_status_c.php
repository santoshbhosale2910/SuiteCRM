<?php
 // created: 2018-06-05 21:18:20
$dictionary['Prospect']['fields']['jjwg_maps_geocode_status_c']['inline_edit']=1;

 ?>