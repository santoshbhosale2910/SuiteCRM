<?php
 // created: 2018-06-05 21:18:18
$dictionary['Prospect']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 ?>