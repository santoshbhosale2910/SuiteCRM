<?php
 // created: 2018-06-05 21:18:08
$dictionary['Meeting']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 ?>