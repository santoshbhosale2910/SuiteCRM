<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['sb_pricebook'] = 'sb_pricebook';
$beanFiles['sb_pricebook'] = 'modules/sb_pricebook/sb_pricebook.php';
$moduleList[] = 'sb_pricebook';

?>