<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/sb_pricebook_aos_productsMetaData.php');

?>