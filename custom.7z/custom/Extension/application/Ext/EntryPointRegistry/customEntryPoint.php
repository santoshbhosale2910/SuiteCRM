<?php
$entry_point_registry['getCategoryProducts'] = array(
    'file' => 'custom/modules/AOS_Quotes/getCategoryProducts.php',
    'auth' => false,
);