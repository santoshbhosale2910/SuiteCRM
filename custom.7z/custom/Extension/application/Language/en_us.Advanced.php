<?php
$app_strings['LBL_ACCEPT_CANCELLED'] = 'Date Cancelled';
