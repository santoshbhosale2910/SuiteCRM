<?php 
 //WARNING: The contents of this file are auto-generated


$entry_point_registry['getCategoryProducts'] = array(
    'file' => 'custom/modules/AOS_Quotes/getCategoryProducts.php',
    'auth' => false,
);
?>