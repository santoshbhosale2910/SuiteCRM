<?php
// created: 2018-06-28 20:13:48
$key = array (
  0 => '466300d3-9be1-85ec-5ed3-5b35253236e9',
);