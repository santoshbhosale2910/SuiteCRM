<?php
$GLOBALS['app_list_strings']['chargemodel_list']=array (
  1 => 'Flat Fee Pricing',
  2 => 'Per Unit Pricing',
  3 => 'Overage Pricing',
  4 => 'Volume Pricing',
  5 => 'Tiered Pricing',
  6 => 'Tiered with Overage Pricing',
);
$GLOBALS['app_list_strings']['charge_type_id_list']=array (
  0 => 'One Time Charge',
  1 => 'Recurring Charge',
  2 => 'Usage Charge',
);
$GLOBALS['app_list_strings']['uom_list']=array (
  'Call' => 'Call',
  'Campaign' => 'Campaign',
  'Each' => 'Each',
  'Minute' => 'Minute',
  'Number' => 'Number',
  'Port' => 'Port',
  'Upload' => 'Upload',
  'User' => 'User',
);