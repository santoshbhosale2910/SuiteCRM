<?php 
 //WARNING: The contents of this file are auto-generated


 // created: 2018-06-05 21:18:10
$dictionary['Meeting']['fields']['jjwg_maps_address_c']['inline_edit']=1;

 

 // created: 2018-06-05 21:18:09
$dictionary['Meeting']['fields']['jjwg_maps_geocode_status_c']['inline_edit']=1;

 

 // created: 2018-06-05 21:18:08
$dictionary['Meeting']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 

 // created: 2018-06-05 21:18:08
$dictionary['Meeting']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 
?>