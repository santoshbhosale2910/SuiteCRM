<?php
ini_set('display_errors','1');
error_reporting(1);
    if (!defined('sugarEntry') || !sugarEntry)
        die('Not A Valid Entry Point');
    $categoryId = $_GET['category_id'];
    $productCategories = BeanFactory::getBean('AOS_Product_Categories', $categoryId);
    $arrProductList = array();
    if ($productCategories->load_relationship('aos_products')) {
        //Fetch related beans
        $relatedBeans = $productCategories->aos_products->getBeans();
        $field_list = array("name", "id", "part_number", "cost", "price", "description", "currency_id", "charge_model_id_c", "charge_type_id_c", "event_id_c", "uom_c");
        
        $priceFieldList = array("sb_pricebook_type", "amount", "amount_usdollar", "currency_id", "version_optimized_lock", "price_format", "tier_price", "starting_unit", "ending_unit", "start_date", "end_date");
        if(!empty($relatedBeans)) {
            $counter = 0;
            foreach($relatedBeans as $row) {
                $arrPriceList = array();
                $productsBean = BeanFactory::getBean('AOS_Products', $row->id);
                if ($productsBean->load_relationship('sb_pricebook')) {
                    //Fetch related beans
                    $relatedPriceBeans = $productsBean->sb_pricebook->getBeans();
                    $arrPriceList = $relatedPriceBeans;
                    if(!empty($relatedBeans)) {
                        $arrProductList[$counter]['pricebook'] = $arrPriceList;
                    }
                }
                
                foreach($field_list as $fieldName){
                    $arrProductList[$counter][$fieldName] = $row->$fieldName;
                }
                $counter++;
            }
        }
        
        echo json_encode($arrProductList);
        exit();

    }
    
	