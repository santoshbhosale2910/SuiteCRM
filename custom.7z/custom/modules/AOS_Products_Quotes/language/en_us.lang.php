<?php
// created: 2018-06-25 23:02:24
$mod_strings = array (
  'LBL_ADD_PRD_CATEGORY' => 'Add Product Category',
  'LBL_CATEGORY_ID_AOS_PRODUCT_CATEGORIES_ID' => 'Category Id (related  ID)',
  'LBL_CATEGORY_ID' => 'Category Id',
);