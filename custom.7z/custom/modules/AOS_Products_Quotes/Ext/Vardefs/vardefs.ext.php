<?php 
 //WARNING: The contents of this file are auto-generated


 // created: 2018-06-15 19:36:31
$dictionary['AOS_Products_Quotes']['fields']['category_id_c']['inline_edit']='1';
$dictionary['AOS_Products_Quotes']['fields']['category_id_c']['labelValue']='Category Id';

 
?>