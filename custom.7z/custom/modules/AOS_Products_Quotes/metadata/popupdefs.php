<?php
$popupMeta = 
array (
  'moduleMain' => 'AOS_Products_Quotes',
  'varName' => 'AOS_Products_Quotes',
  'orderBy' => 'aos_products_quotes.name',
  'whereClauses' => 
  array (
    'name' => 'aos_products_quotes.name',
  ),
  'searchInputs' => 
  array (
    0 => 'aos_products_quotes_number',
    1 => 'name',
    2 => 'priority',
    3 => 'status',
  ),
);
;
?>
