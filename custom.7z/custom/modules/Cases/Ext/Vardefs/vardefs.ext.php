<?php 
 //WARNING: The contents of this file are auto-generated


 // created: 2018-06-05 21:18:00
$dictionary['Case']['fields']['jjwg_maps_address_c']['inline_edit']=1;

 

 // created: 2018-06-05 21:18:00
$dictionary['Case']['fields']['jjwg_maps_geocode_status_c']['inline_edit']=1;

 

 // created: 2018-06-05 21:17:59
$dictionary['Case']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 

 // created: 2018-06-05 21:17:58
$dictionary['Case']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 
?>