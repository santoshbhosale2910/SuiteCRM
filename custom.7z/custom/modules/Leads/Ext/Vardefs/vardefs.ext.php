<?php 
 //WARNING: The contents of this file are auto-generated


 // created: 2018-06-05 21:18:07
$dictionary['Lead']['fields']['jjwg_maps_address_c']['inline_edit']=1;

 

 // created: 2018-06-05 21:18:06
$dictionary['Lead']['fields']['jjwg_maps_geocode_status_c']['inline_edit']=1;

 

 // created: 2018-06-05 21:18:05
$dictionary['Lead']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 

 // created: 2018-06-05 21:18:04
$dictionary['Lead']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 
?>