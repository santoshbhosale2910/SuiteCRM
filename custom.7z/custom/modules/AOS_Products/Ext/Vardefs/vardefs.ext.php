<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2018-07-11 20:57:32
$dictionary["AOS_Products"]["fields"]["sb_pricebook_aos_products"] = array (
  'name' => 'sb_pricebook_aos_products',
  'type' => 'link',
  'relationship' => 'sb_pricebook_aos_products',
  'source' => 'non-db',
  'module' => 'sb_pricebook',
  'bean_name' => 'sb_pricebook',
  'side' => 'right',
  'vname' => 'LBL_SB_PRICEBOOK_AOS_PRODUCTS_FROM_SB_PRICEBOOK_TITLE',
);


 // created: 2018-07-11 19:19:24
$dictionary['AOS_Products']['fields']['charge_model_id_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['charge_model_id_c']['labelValue']='Charge Model Id';

 

 // created: 2018-07-11 19:22:38
$dictionary['AOS_Products']['fields']['charge_type_id_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['charge_type_id_c']['labelValue']='Charge Type Id';

 

 // created: 2018-07-11 19:14:47
$dictionary['AOS_Products']['fields']['default_qty_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['default_qty_c']['labelValue']='Default Qty';

 

 // created: 2018-07-11 19:23:28
$dictionary['AOS_Products']['fields']['event_id_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['event_id_c']['labelValue']='Event Id';

 

 // created: 2018-07-11 19:16:15
$dictionary['AOS_Products']['fields']['tenant_id_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['tenant_id_c']['labelValue']='Tenant Id';

 

 // created: 2018-07-11 19:26:03
$dictionary['AOS_Products']['fields']['uom_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['uom_c']['labelValue']='UOM';

 

 // created: 2018-07-11 19:13:29
$dictionary['AOS_Products']['fields']['version_optimized_lock_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['version_optimized_lock_c']['labelValue']='Version Optimized Lock';

 
?>