<?php
// created: 2018-07-11 19:26:03
$mod_strings = array (
  'LBL_VERSION_OPTIMIZED_LOCK' => 'Version Optimized Lock',
  'LBL_DEFAULT_QTY' => 'Default Qty',
  'LBL_TENANT_ID' => 'Tenant Id',
  'LBL_CHARGE_MODEL_ID' => 'Charge Model Id',
  'LBL_CHARGE_TYPE_ID' => 'Charge Type Id',
  'LBL_EVENT_ID' => 'Event Id',
  'LBL_UOM' => 'UOM',
);