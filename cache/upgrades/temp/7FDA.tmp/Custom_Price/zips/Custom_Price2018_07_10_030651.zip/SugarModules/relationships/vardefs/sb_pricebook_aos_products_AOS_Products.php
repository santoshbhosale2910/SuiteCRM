<?php
// created: 2018-07-10 03:06:50
$dictionary["AOS_Products"]["fields"]["sb_pricebook_aos_products"] = array (
  'name' => 'sb_pricebook_aos_products',
  'type' => 'link',
  'relationship' => 'sb_pricebook_aos_products',
  'source' => 'non-db',
  'module' => 'sb_pricebook',
  'bean_name' => 'sb_pricebook',
  'vname' => 'LBL_SB_PRICEBOOK_AOS_PRODUCTS_FROM_SB_PRICEBOOK_TITLE',
);
