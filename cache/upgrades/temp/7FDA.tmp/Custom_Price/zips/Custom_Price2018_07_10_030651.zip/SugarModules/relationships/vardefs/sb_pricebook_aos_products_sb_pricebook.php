<?php
// created: 2018-07-10 03:06:50
$dictionary["sb_pricebook"]["fields"]["sb_pricebook_aos_products"] = array (
  'name' => 'sb_pricebook_aos_products',
  'type' => 'link',
  'relationship' => 'sb_pricebook_aos_products',
  'source' => 'non-db',
  'module' => 'AOS_Products',
  'bean_name' => 'AOS_Products',
  'vname' => 'LBL_SB_PRICEBOOK_AOS_PRODUCTS_FROM_AOS_PRODUCTS_TITLE',
);
